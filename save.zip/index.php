<?php

require_once("bootstrap.php");

use core\Application;

new Application();
