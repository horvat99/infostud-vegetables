<?php

namespace core;

class View
{
    protected $viewFile;
    protected $viewData;

    public function __construct($viewFile,$viewData)
    {
        $this->viewFile = $viewFile;
       // var_dump($this->viewFile);
        $this->viewData = $viewData;
        ini_set('xdebug.var_display_max_depth', '10');
        ini_set('xdebug.var_display_max_children', '256');
        ini_set('xdebug.var_display_max_data', '1024');
     //   var_dump($this->viewData);
    }

    public function render()
    {
        $this->viewFile = str_replace('\\','/',$this->viewFile);
        if (file_exists(VIEW . $this->viewFile . '.phtml')){
            include VIEW.$this->viewFile.'.phtml';
        }
    }
}