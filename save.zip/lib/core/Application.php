<?php

namespace core;
use controller\homeController;

class Application
{
    protected $controller ='homeController';
    protected $action = 'index';
    protected $prams =[];

    public function __construct()
    {
        $this->validateURL();
        //echo $_SERVER['REQUEST_URI'];
        $this->prepareURL();
     //   echo $this->controller, '<br>' , $this->action, print_r($this->prams);
        if (file_exists(CONTROLLER. $this->controller . '.php')){
            $this->controller = new homeController();
            if (method_exists($this->controller,$this->action)){
                call_user_func_array([$this->controller,$this->action],$this->prams);
            }
        }
    }


    protected function prepareURL()
    {
        $request = trim($_SERVER['REQUEST_URI'],'/');
      //  var_dump($request);
        if (!empty($request)){
            $url = explode('/',$request);
            $this->controller = isset($url[0]) ? $url[0].'Controller' : 'homeController';
           // var_dump($this->controller);
            $this->action = isset($url[1]) ? $url[1] : 'index';
            unset($url[0],$url[1]);
            $this->prams = !empty($url) ? array_values($url) : [];
        }

    }

    private function validateURL()
    {
        $filePath = (ltrim($_SERVER["REQUEST_URI"], '/'));
        if (!empty($filePath)){
            $path = ltrim(__DIR__.DIRECTORY_SEPARATOR.$filePath,'/');
            $pathArray = explode('/',$path);
           /* ini_set('xdebug.var_display_max_depth', '10');
            ini_set('xdebug.var_display_max_children', '256');
            ini_set('xdebug.var_display_max_data', '1024');
            var_dump($pathArray);*/
            $file = $pathArray[count($pathArray)-1];
            if (is_numeric($file))
            {
                $file = $pathArray[count($pathArray)-2];
            }
            $fol = VIEW .'home/'. $file.'.phtml';
            //echo $fol;
            if (!file_exists($fol))
            {
                echo '<h4 style="font-size: 5em; text-align: center">Error 404 not found</h4>';
            }
        }
    }
    /*
    protected $controller = 'homeController';
    protected $action = 'index';
    protected $prams = [];

    public function __construct()
    {
        $this->prepareURL();
        //echo $this->controller, '<br>' , $this->action , print_r($this->prams);
        if (file_exists(CONTROLLER. $this->controller . '.php')){
            $this->controller = new homeController();
            if (method_exists($this->controller,$this->action)){
                call_user_func_array([$this->controller,$this->action],$this->prams);
            }
        }
    }

    protected function prepareURL(){
        $request = trim($_SERVER['REQUEST_URI'],'/');
        if (!empty($request))
        {
            $url = explode('/',$request);
            $this->controller = isset($url[0]) ? $url[0].'Controller' : 'homeController';
            $this->action = isset($url[1]) ? $url[1] : 'index';
            unset($url[0],$url[1]);
            $this->prams = !empty($url) ? array_values($url) : [];
        }
    }*/
}