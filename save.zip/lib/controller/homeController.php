<?php

namespace controller;
use core\Controller;

class homeController extends Controller
{
    public function index()
    {
        //echo 'I am in in ' . __CLASS__ . ' method ' , __METHOD__;
        //echo 'Id: is ' . $id . ' and Name is: ' .$name;
        $this->view('home\index');
       /* ini_set('xdebug.var_display_max_depth', '10');
        ini_set('xdebug.var_display_max_children', '256');
        ini_set('xdebug.var_display_max_data', '1024');
        var_dump($this);*/
        $this->view->render();

    }

    public function vegetables(){
        //echo 'I am in in ' . __CLASS__ . ' method ' , __METHOD__;
        $this->view('home\vegetables');
        $this->view->render();
    }
    public function search(){
        //echo 'I am in in ' . __CLASS__ . ' method ' , __METHOD__;
        $this->view('home\search');
        $this->view->render();
    }
    public function vegetable($id=''){
        $this->view('home\vegetable',[
            'id' => $id
        ]);
        $this->view->render();
    }
    public function addVegetable()
    {
        $this->view('home\addvegetable');
        $this->view->render();
    }

    /*
    public function index($id='',$name='')
    {
        $this->view('home\index', [
            'name' => $name,
            'id' => $id
        ]);
        $this->view->render();
    }
    public function aboutUs()
    {
        echo 'szia';
        $this->view('home\aboutUs');
        $this->view->render();
    }*/
}